# haskell-learn
学习Haskell产生的代码

结合一些教程以及书籍产生的一些Haskell代码练习。
一步一步迭代，从最简单的开始。

import System.Random如果报错，可能是因为ghc没有默认将它添加到库中，你需要去手动下载，执行以下命令：
```Shell
cabal install random
```

